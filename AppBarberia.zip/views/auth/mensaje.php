<h1 class="nombre-pagina">Confirma tu cuenta</h1>
<p class="descripcion-pagina">Hemos enviado un mensaje de confirmacion a tu bandeja de correo eléctronico.</p>

<div class="acciones">
        <a href="/">¿Ya tienes una cuenta? Inicia sesión</a>
        <a href="/forgot">¿Olvidaste tu password?</a>
</div>