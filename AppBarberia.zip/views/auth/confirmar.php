<h1 class="nombre-pagina">Confirmación de cuenta</h1>

<?php include_once __DIR__.'/../templates/alertas.php';

?>
<div class="acciones centrar">
        <a href="/">Inicia sesión</a>
</div>